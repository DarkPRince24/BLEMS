<div class="pull-right hidden-xs"> <b>Version</b> 0.0.1 </div>
<strong>Copyright &copy; 2025 <a href="http://" target="_blank">JOE MARIE BRAÑA TABION</a>.</strong> All rights reserved.