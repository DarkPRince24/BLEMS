<?php
// Include the correct path to your functions.php
include_once('../library/functions.php');  // Adjust this based on where functions.php is located

// Fetch the records
$records = getBookingRecords();  // Fetch the records before the HTML block

$utype = '';
$type = $_SESSION['calendar_fd_user']['type'];
if($type == 'admin') {
    $utype = 'on';
}
?>

<div class="col-md-12">
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Event Booking Details</h3><hr><hr>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <table class="table table-bordered">
        <tr>
          <th style="width: 10px">#</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Booking Date</th>
          <th style="width: 140px">Number of People</th>
          <th>Event Description</th> <!-- Added -->
          <th style="width: 100px">Status</th>
          <?php if($utype == 'on') { ?>
          <th>Action</th>
          <?php } ?>
        </tr>
        <?php
        $idx = 1;
        foreach($records as $rec) {
          extract($rec);  // Extracts all fields from $rec including event_description
          $stat = '';
          if($status == "PENDING") {
            $stat = 'warning';
          } else if ($status == "APPROVED") {
            $stat = 'success';
          } else if($status == "DENIED") {
            $stat = 'danger';
          }
        ?>
        <tr>
          <td><?php echo $idx++; ?></td>
          <td><a href="<?php echo WEB_ROOT; ?>views/?v=USER&ID=<?php echo $user_id; ?>"><?php echo strtoupper($user_name); ?></a></td>
          <td><?php echo $user_email; ?></td>
          <td><?php echo $user_phone; ?></td>
          <td><?php echo $res_date; ?></td>
          <td><?php echo $count; ?></td>
          <td><?php echo isset($event_description) ? htmlspecialchars($event_description) : 'No Description'; ?></td> <!-- Display event_description -->
          <td><span class="label label-<?php echo $stat; ?>"><?php echo $status; ?></span></td>
          <?php if($utype == 'on') { ?>
          <td>
            <?php if($status == "PENDING") { ?>
              <a href="javascript:approve('<?php echo $user_id ?>');">Approve</a>&nbsp;/&nbsp;
              <a href="javascript:decline('<?php echo $user_id ?>');">Denied</a>&nbsp;/&nbsp;
              <a href="javascript:deleteUser('<?php echo $user_id ?>');">Delete</a>
            <?php } else { ?>
              <a href="javascript:deleteUser('<?php echo $user_id ?>');">Delete</a>
            <?php } ?>
          </td>
          <?php } ?>
        </tr>
        <?php } ?>
      </table>
    </div>
    <!-- /.box-body -->
    <div class="box-footer clearfix">
      <?php echo generatePagination(); ?> 
    </div>
  </div>
  <!-- /.box -->
</div>

<script language="javascript">
function approve(userId) {
  if(confirm('Are you sure you want to Approve it?')) {
    window.location.href = '<?php echo WEB_ROOT; ?>api/process.php?cmd=regConfirm&action=approve&userId='+userId;
  }
}
function decline(userId) {
  if(confirm('Are you sure you want to Decline the Booking?')) {
    window.location.href = '<?php echo WEB_ROOT; ?>api/process.php?cmd=regConfirm&action=denide&userId='+userId;
  }
}
function deleteUser(userId) {
  if(confirm('Deleting this user will also delete their booking from the calendar.\n\nAre you sure you want to proceed?')) {
    window.location.href = '<?php echo WEB_ROOT; ?>api/process.php?cmd=delete&userId='+userId;
  }
}
</script>
