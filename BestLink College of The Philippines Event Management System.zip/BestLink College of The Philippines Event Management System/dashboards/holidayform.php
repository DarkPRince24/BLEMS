<!-- Include jQuery and jQuery UI -->
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!-- Horizontal Form -->
<div class="box box-info">
  <div class="box-header with-border">
    <h3 class="box-title">School Event's Form</h3>
  </div>
  <!-- /.box-header -->
  <!-- form start -->
  <form class="form-horizontal" action="<?php echo WEB_ROOT; ?>api/process.php?cmd=holiday" method="post">
    <div class="box-body">
      <div class="form-group">
        <label for="eventDate", , class="col-sm-8 control-label",>School Event Date</label><hr><hr>
        <div class="col-sm-12">
          <input type="text" class="form-control input-sm" id="eventDate" name="date" placeholder="yyyy-mm-dd" required>
        </div>
      </div>
	  
      <div class="form-group">
        <label for="eventDetails" class="col-sm-8 control-label">School Event Details</label><hr><hr>
        <div class="col-sm-12">
          <input type="text" class="form-control input-sm" id="eventDetails" name="reason" placeholder="School Event Details" minlength="30" required>
        </div>
      </div>
    </div>
    <!-- /.box-body -->
    <div class="box-footer">
      <button type="submit" class="btn btn-info pull-right">Add Event</button>
    </div>
    <!-- /.box-footer -->
  </form>
</div>
<!-- /.box -->

<script>
  $(document).ready(function() {
    $("#eventDate").datepicker({
      dateFormat: "yy-mm-dd",
      changeMonth: true,
      changeYear: true
    });
  });
</script>
