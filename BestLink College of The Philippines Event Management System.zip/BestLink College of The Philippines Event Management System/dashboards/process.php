<?php 

require_once '../library/config.php';
require_once '../library/functions.php';
require_once '../library/mail.php';

$cmd = isset($_GET['cmd']) ? $_GET['cmd'] : '';

switch($cmd) {
    case 'create':
        createUser();
        break;
    
    case 'change':
        changeStatus();
        break;
    
    case 'book': // New case for booking events
        bookEvent(); // Add the booking function here
        break;

    default:
        break;
}

function createUser() {
    $name       = $_POST['name'];
    $address    = $_POST['address'];
    $phone      = $_POST['phone'];
    $email      = $_POST['email'];
    $type       = $_POST['type'];

    //TODO first check if that date has a holiday
    $hsql   = "SELECT * FROM tbl_users WHERE name = '$name'";
    $hresult = dbQuery($hsql);
    if (dbNumRows($hresult) > 0) {
        $errorMessage = 'User with same name already exists. Please try another day.';
        header('Location: ../views/?v=CREATE&err=' . urlencode($errorMessage));
        exit();
    }
    $pwd = random_string();
    $sql = "INSERT INTO tbl_users (name, pwd, address, phone, email, type, status, bdate)
            VALUES ('$name', '$pwd', '$address', '$phone', '$email', '$type', 'active', NOW())";  
    dbQuery($sql);
    
    // send email on registration confirmation
    $bodymsg = "User $name booked the date slot on $bkdate. Requesting you to please take further action on user booking.<br/>Mbr/>Tousif Khan";
    $data = array('to' => '$email', 'sub' => 'Booking on $rdate.', 'msg' => $bodymsg);
    //send_email($data);
    header('Location: ../views/?v=USERS&msg=' . urlencode('User successfully registered.'));
    exit();
}

function changeStatus() {
    $action     = $_GET['action'];
    $userId     = (int)$_GET['userId'];
    
    $sql = "UPDATE tbl_users SET status = '$action' WHERE id = $userId";  
    dbQuery($sql);
    
    // send email on status change
    $bodymsg = "User $name booked the date slot on $bkdate. Requesting you to please take further action on user booking.<br/>Mbr/>Tousif Khan";
    $data = array('to' => '$email', 'sub' => 'Booking on $rdate.', 'msg' => $bodymsg);
    //send_email($data);
    header('Location: ../views/?v=USERS&msg=' . urlencode('User status successfully updated.'));
    exit();
}

function bookEvent() {
    // Get data from POST request
    $userId            = $_POST['userId'];
    $address           = $_POST['address'];
    $phone             = $_POST['phone'];
    $email             = $_POST['email'];
    $rdate             = $_POST['rdate'];
    $rtime             = $_POST['rtime'];
    $ucount            = $_POST['ucount'];
    $event_description = $_POST['event_description'];

    // Check if all required fields are present
    if (empty($userId) || empty($rdate) || empty($ucount) || empty($event_description)) {
        echo "Error: Required fields are missing.";
        exit();
    }

    // Sanitize inputs (basic example - consider using prepared statements)
    $userId            = (int)$userId; // Make sure it's an integer
    $address           = dbEscape($address);
    $phone             = dbEscape($phone);
    $email             = dbEscape($email);
    $rdate             = dbEscape($rdate);
    $rtime             = dbEscape($rtime);
    $ucount            = (int)$ucount;
    $event_description = dbEscape($event_description);

    // Insert event into the database
    $sql = "INSERT INTO tbl_reservations (user_id, address, phone, email, rdate, rtime, ucount, event_description)
            VALUES ('$userId', '$address', '$phone', '$email', '$rdate', '$rtime', '$ucount', '$event_description')";
    
    // Execute query
    if (dbQuery($sql)) {
        echo "Event booked successfully!";
        header('Location: ../views/?v=EVENTS&msg=' . urlencode('Event successfully booked.'));
        exit();
    } else {
        echo "Error booking event.";
    }
}
?>
